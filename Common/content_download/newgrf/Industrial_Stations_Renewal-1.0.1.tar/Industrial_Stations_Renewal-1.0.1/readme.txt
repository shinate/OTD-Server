Industrial Stations Renewal (ISR) v1.0.1
========================================

1 About
  1.1 Version Requirements
2 Parameters
3 Detailed Description
  3.1 Animated Stations
  3.2 PBS Controlled Doors
  3.3 Buffers
  3.4 Single Sided Platforms and Ramps
  3.5 Truck Parking
  3.6 Cargo Display on Station Tiles
4 Bug Reports
5 Translations
6 Known Issues
7 License
8 Credits



1 About
=======

Industrial Stations Renewal (ISR) is a set of stations for OpenTTD. It
includes stations and facilities suitable for freight cargo. It has
support for the standard TTD cargos and many of the additional cargos
supplied by industry GRFs.

Features include animation of the various cranes and warehouse doors
etc. Most animations are triggered by activity at the station, such as
trains arriving/leaving and cargo being delivered. Platforms and
non-track tiles are included that display the amount of cargo waiting
at the station.



1.1 Version Requirements
------------------------

OpenTTD 1.2.0 or newer.

ISR v1.0.1 does not support TTDPatch.
TTDPatch players should use ISR v0.8.2.



2 Parameters
============

1) Docks
    0: enable new dock (default)
    1: disable new dock

2) Ship depot
    0: enable new ship depot
    1: disable new ship depot (default)

With no parameters set they default to '0 1' i.e. new docks enabled,
ship depot disabled.



3 Detailed Description
======================

3.1 Animated Stations
---------------------

Animations that span multiple tiles (overhead crane, gantry cranes etc.)
require some special considerations when modifying the station. If
over-building or removing tiles from an animation, it is advisable to
remove or overbuild all the tiles of the animation (i.e. the whole
platform). Graphical errors may occur otherwise.

Stations and station tiles that are animated:
* Goods station A
* Steel mill station
* Tower crane
* Crane on rails
* Overhead crane
* Gantry crane (modern)
* Gantry crane (classic)
* Conveyor belt (minerals)
* Main office
* Shipping office
* Large warehouse
* Small warehouse
* Modern warehouse
* Brick warehouse
* Front loader (minerals)
* Forklift (crates)
* Forklift (containers)
* Freight station
* Heavy Freight Station



3.2 PBS Controlled Doors
------------------------

Some buildings such as the engine sheds and high security sheds, have
doors controlled by PBS (Path Based Signalling). The doors will also
remain closed if no rails are connected.

In cases where PBS is disabled, the doors open when a rail, a station
platform or a buffer is connected to the shed door.

If PBS is enabled, in addition to requiring a connecting rail, the doors
only open when the track is reserved. For this to work, always build a
PBS signal on the track leading to the building, otherwise the track
will not be reserved and the door will remain closed.



3.3 Buffers
-----------

The north/south orientation of the buffers is automatically controlled
by the direction of connected rails or platforms. If there is a track
that the buffer can connect to, it will orientate itself in the
direction of the track. If there is track both sides of the buffer, a
back-to-back double buffer will be used.



3.4 Single Sided Platforms and Ramps
------------------------------------

The ramps for single sided platforms are semi-automatic. The north/south
orientation is dependant on the ramp type used, but the platform side
(front or back) is dependant on the adjoining platforms.

If a single sided platform is placed next to the high end of a ramp
tile, a ramp will only be shown on the same side as the platform.

If no single sided platform is placed next to the high end but a single
sided platform is placed next to the low end, the side with the platform
will show a continuation of that platform and the other side will show a
ramp. This allows a transition ramp to be built, between single sided
and normal (double sided) high platforms.



3.5 Truck Parking
-----------------

The truck parking tiles display trucks depending on the amount of cargo
waiting at the station. It works with all cargo types and displays truck
varieties that suit the waiting cargo.



3.6 Cargo Display on Station Tiles
----------------------------------

This list shows the types of cargo that must be present at a station, in
order for that station to display cargo on its platforms. Note, no
attempt has been made to restrict which types of cargo a station will
accept. All industrial stations behave as normal stations as far as the
game is concerned.

Cargos included in this list are those (or their packaging - containers
etc.) that are displayed graphically. Cargos not on this list are those
that would be stored in silos, tanks etc.

Mineral silo/Mineral piles/Mineral platforms (show cargo type dependant
graphics)
* coal
* iron ore
* copper ore
* clay
* gravel
* limestone
* sand
* bauxite

Livestock station/Pig yard/Cattle docks/Cattle sheds
* livestock

Wood loading station/Wood platforms/Wood piles
* wood
* tropic wood

Oil Storage Tanks (level indication only)
* oil
* petrol
* refined products

Steel mill station
* steel/metal

Goods stations (before 1960)/General cargo platforms/General cargo tiles
* mail
* goods
* paper
* food
* fruit
* fish
* wool
* glass
* ceramics
* engineering supplies
* manufacturing supplies
* farm supplies
* building materials
* recyclables
* scrap metal
* sugar
* coffee

Goods stations (post 1960)/Container loading platforms/Container tiles
* mail
* goods
* paper
* food
* fruit
* fish
* wool
* glass
* ceramics
* bricks
* vehicles
* engineering supplies
* manufacturing supplies
* farm Supplies
* building materials
* recyclables
* scrap metal
* sugar
* coffee

Steel platforms/Steel tiles
* steel/metal

Copper platforms/Copper tiles
* copper
* goods (if copper is not available as a specific cargo)

Barrel platforms/Barrel tiles
* oil
* goods
* water
* rubber
* petrol
* fertiliser
* dyes
* refined products
* plastic
* milk
* farm supplies
* alcohol

Plank platforms/Plank tiles
* wood products
* lumber
* building materials
* goods (if neither wood products nor lumber is available as a specific
  cargo)

Car tiles
* vehicles
* goods (if vehicles are not available as a specific cargo)

Paper loading station/Paper platforms/Paper tiles
* paper

Fruit loading station/Fruit platforms/Fruit tiles
* fruit
* fruit (and veg)

Rubber loading station (shows barrels)
* oil
* rubber
* petrol
* fertiliser
* dyes
* refined products
* plastic
* alcohol
* farm supplies

Forklift platform (shows cargo type dependant graphics - crates, barrels
or paper)
* mail
* oil
* goods
* valuables
* paper
* food
* fruit
* rubber
* gold
* diamonds
* petrol
* fish
* wool
* glass
* ceramics
* fertiliser
* dyes
* refined products
* plastic
* alcohol
* building materials
* engineering supplies
* farm supplies
* fruit (and veg)
* milk
* manufacturing supplies
* recyclables
* scrap metal
* sugar
* coffee

High security parking (shows armoured trucks)
* valuables
* gold
* diamonds



4 Bug Reports
=============

Please report any bugs found to the Transport Tycoon forum in the
Industrial Stations Renewal topic
(http://www.tt-forums.net/viewtopic.php?f=26&t=27112) or at the DevZone
ISR issue tracker (http://dev.openttdcoop.org/projects/isr/issues)



5 Translations
==============

Additions of new languages or updates to existing translations are
always welcome.

Translations are managed by the DevZone's central NewGRF translations
service which allows you to translate the NewGRFs conveniently from
your web browser. It's found at:

http://translator.openttdcoop.org

You'll need to login there with your account from the #openttdcoop
DevZone (http://dev.openttdcoop.org). Simply register and apply as
translator for the language of your choice.

If you want to translate offline, obtain the language file from the
repository and use the English one as the base language. In those cases
post updates or new translations as an issue in the project's issue
tracker (http://dev.openttdcoop.org/projects/isr/issues)



6 Known Issues
==============

The Marshalling yard does not display monorail or maglev tracks. It is
also incompatible with railtypes GRFs using a gauge that differs from
the standard TTD track, e.g. the xUSSR Railway Set (xussr.grf) or the
Finescale Standard Gauge set (pb_trax.grf). See issue #4307
(http://dev.openttdcoop.org/issues/4307).

Some railtypes GRFs have features that lie outside of the normal track
width, e.g. the third rail of the Metro Track from the Metro Track Set
(metrotrackset.grf). Due to the way that ISR uses track overlays with
some transparency, these features will be only partially visible when
used with ISR ground level station tiles.

Some versions of OpenTTD (including 1.2.3) have an issue (FS#5335) that
prevents stations from using snow and desert ground tiles. This was
fixed at r24715 and works correctly in OpenTTD 1.3.0.



7 Licensing
===========

Industrial Stations Renewal is licensed under the GNU General Public
License version 2.

Industrial Stations Renewal for OpenTTD.

Copyright © 2006-2014 the ISR contributors (see credits).

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the License, or (at your
option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.



Some graphics used for Industrial Stations Renewal are based on graphics
originating from the Industrial Stations Set v0.98 (jcindsta[w].grf):

The Industrial Stations Set is licensed under the GNU General Public 
License version 2.

The Industrial Stations Set for OpenTTD and TTDPatch
Copyright © 2005 by certain members of the Transport Tycoon Forums
(norfolksouthern37, Arte Pro 34, Oz and Oracle)



The paper graphics used for Industrial Stations Renewal are based on
graphics originating from the OpenGFX Graphics base Set:

OpenGFX is licensed under the GNU General Public License version 2.

The OpenGFX Graphics base Set for OpenTTD
Copyright © 2007-2011 by the OpenGFX team
Website: http://dev.openttdcoop.org/projects/opengfx



8 Credits
=========

Graphics by:

    Sanchimaru
    Oz
    norfolksouthern37
    Zimmlock
    Ben_K
    Born Acorn
    mph
    Arte Pro 34
    andythenorth

Coded by:

    Maedhros
    mart3p
    planetmaker (action 14)

Translations by:

    Spanish - Sanchimaru, maquinista, SilverSurferZzZ, absay
    German - Aylo, zypa, planetmaker, Jogio
    Finnish - Vemarkis, alluke, Arexander
    French - cmoiromain, Wallyweb
    Estonian - Alselius, ISA
    Dutch - Foobar
    Russian - dadesign, George
    Polish - wojteks86
    Croatian - Voyager One
    Hungarian - oklmernok, colossal404
    Korean - Telk
    Simplified Chinese - dirace, siu238X
    Scottish Gaelic - GunChleoc
    Serbian - Voyager One
    Luxembourgish - Phreeze
    Norwegian (Bokmal) - Trond
    Traditional Chinese - siu238X
    Italian - Snail, Voyager One
    Catalan - juanjo
